//
//  ViewController.swift
//  MFSDKDemo
//
//  Created by Sandeep on 26/09/17.
//  Copyright © 2017 Sandeep. All rights reserved.
//

import UIKit
import MFSDK

class ViewController: UIViewController {

    @IBOutlet weak var errorcodeLabel : UILabel!
    @IBOutlet weak var resultLabel : UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        // set order status delegate Method to get payment status
        MFOrderStatusRequest.sharedInstance.delegateOrderStatus = self
    }

    @IBAction func createInvoiceDidPRessed(_ sender: AnyObject){
        
        // customer details
        let customer = MFCustomer()
        
        customer.customerName = "customer name " //Required
        customer.customerEmailAddress = "email address"//Required
        customer.customerMobileNo = "mobile no"//Required
        customer.customerGender = ""
        customer.customerDOB = ""
        customer.customerCivilID = ""
        customer.customerArea = ""
        customer.customerBlockNo = ""
        customer.customerStreet = ""
        customer.customerAvenue = ""
        customer.customerBuildingNo = ""
        customer.customerFloorNo = ""
        customer.customerApartment = ""
        
        
        //at list one prodduct Required
        let productList = NSMutableArray()
        
        for _ in 0..<5 {
            
            // MFProduct Details
            let product = MFProductDetails()
            
            product.productName = "ABC"
            product.productPrice = 30.5
            product.productQuntity = 4
            
            productList.add(product)
        }
        
        //place order with SDK
        MFPaymentRequest.sharedInstance.placeOrder(customer: customer, productList: productList, subTotal: 150.0, paymentMode: "BOTH", paymentCurrrency: "KWD")
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}
//MFOrder status Delegate methods
extension ViewController : MFOrderStatusRequestDelegate {
    
    func getOrderPaymentStatusSucess(ordetStatus:MFOrderStatusRequestResponse) {
        DispatchQueue.main.async(execute: {
            
            self.errorcodeLabel.text = String(format: "responseCode: %@", ordetStatus.responseCode)
           
            self.resultLabel.text = String(format: "result: %@",ordetStatus.result)
           
            
        })
    }
    
    func getOrderPaymentStatusFailed(ordetStatus:MFOrderStatusRequestResponse) {
        DispatchQueue.main.async(execute: {
            
            self.errorcodeLabel.text = String(format: "responseCode: %@", ordetStatus.responseCode)
            self.resultLabel.text = String(format: "result: %@",ordetStatus.result)
            
        })
    }
}
